/**
 * This function is executed when this Op Mode is selected from the Driver Station.
 */
function runOpMode() {
  Tet1AsDcMotor.setDirection("REVERSE");
  linearOpMode.waitForStart();
  clawAsServo.scaleRange(0.2, 0.8);
  if (linearOpMode.opModeIsActive()) {
    Tet1AsDcMotor.setPower(-0.5);
    armAsServo.setPosition(0.8);
    while (linearOpMode.opModeIsActive()) {
      telemetry.update();
    }
  }
}
