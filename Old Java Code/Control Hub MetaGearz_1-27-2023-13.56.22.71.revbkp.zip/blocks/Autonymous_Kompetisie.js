// IDENTIFIERS_USED=armAsServo,BLAsDcMotor,BRAsDcMotor,FLAsDcMotor,FRAsDcMotor,Tet1AsDcMotor

/**
 * This function is executed when this Op Mode is selected from the Driver Station.
 */
function runOpMode() {
  FLAsDcMotor.setDirection("REVERSE");
  BLAsDcMotor.setDirection("FORWARD");
  FRAsDcMotor.setDirection("REVERSE");
  BRAsDcMotor.setDirection("FORWARD");
  Tet1AsDcMotor.setDirection("REVERSE");
  armAsServo.setDirection("REVERSE");
  linearOpMode.waitForStart();
  armAsServo.scaleRange(0.2, 0.8);
  if (linearOpMode.opModeIsActive()) {
    armAsServo.setPosition(-0.4);
    Tet1AsDcMotor.setPower(8);
    linearOpMode.sleep(1000);
    FLAsDcMotor.setDualPower(0.5, FRAsDcMotor, 0.5);
    BLAsDcMotor.setDualPower(0.5, BRAsDcMotor, 0.5);
    linearOpMode.sleep(1000);
    for (var count = 0; count < 1; count++) {
      FLAsDcMotor.setPower(0);
      BLAsDcMotor.setPower(0);
      FRAsDcMotor.setPower(0);
      BRAsDcMotor.setPower(0);
      linearOpMode.sleep(1000);
    }
  }
}
