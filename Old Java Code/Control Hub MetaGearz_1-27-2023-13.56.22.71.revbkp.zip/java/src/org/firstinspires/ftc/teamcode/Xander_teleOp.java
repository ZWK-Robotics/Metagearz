package org.firstinspires.ftc.teamcode;

import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
import com.qualcomm.robotcore.hardware.Servo;
import com.qualcomm.robotcore.eventloop.opmode.TeleOp;
import com.qualcomm.robotcore.hardware.DcMotor;
import com.qualcomm.robotcore.hardware.DcMotorSimple;

import static java.lang.Math.abs;

@TeleOp(name = "Kompetisie_Tele_Op_Program", group = "Basics")
public class Xander_teleOp extends LinearOpMode {

    private DcMotor FL,BL,FR,BR;
    public Servo arm;
    private DcMotor Tet1;
     

   private NormalDriveController ndController = new NormalDriveController();

   // @Override
    public void runOpMode() throws InterruptedException {
        arm = hardwareMap.servo.get("arm");   //servo claw
         Tet1 = hardwareMap.get(DcMotor.class, "Tet1");   // Lift motor


        ndController.setSpeed(0.00);
        ndController.initMotors();


        waitForStart();

            while (true){
                ndController.setSpeed(gamepad1.right_trigger);
                
                 if (gamepad2.a){
                arm.setPosition(0.4);
            }
            else {
                arm.setPosition(0.8);
                
            }
            
            
             if (gamepad2.right_stick_y > 0){
                Tet1.setPower(20);
       
      
                
      
            }
            else {
                Tet1.setPower(0);
            }


            if (gamepad2.right_stick_y < 0){
                Tet1.setPower(-20);
            }
            else {
                Tet1.setPower(0);
            }


                if (gamepad1.left_stick_y < 0){
                    ndController.moveBackwards();
                }
                if (gamepad1.left_trigger < 0.01) {
                    ndController.stop();
                }

                if (gamepad1.left_stick_y > 0){
                    ndController.moveForward();
                
            }

              if (gamepad1.left_stick_x < 0){
                ndController.turnLeft();
              }

             if (gamepad1.left_stick_x > 0){
                ndController.turnRight();
                 }

             if((gamepad1.right_stick_x == 0) && (gamepad1.left_bumper )){
                 ndController.stafeLeft();
                 }

             if((gamepad1.right_stick_x == 0) && (gamepad1.right_bumper )){
                 ndController.strafeRight();
                 }



                ndController.setSpeed(0.00);


            }






    }


    public class NormalDriveController{
        public double speed;

        public void setSpeed(double Value){
            speed = abs(Value * 0.9);
        }


        public void initMotors(){
            FL = hardwareMap.get(DcMotor.class, "FL");
            BL = hardwareMap.get(DcMotor.class, "BL");
            FR = hardwareMap.get(DcMotor.class, "FR");
            BR = hardwareMap.get(DcMotor.class, "BR");
            FL.setDirection(DcMotorSimple.Direction.REVERSE);
            BR.setDirection(DcMotorSimple.Direction.REVERSE);
        }
        public void stop(){
           FL.setPower(0);
            BL.setPower(0);
            FR.setPower(0);
            BR.setPower(0);

        }

        public void moveForward(){
            FL.setPower(speed);
            BL.setPower(speed);
            FR.setPower(speed);
            BR.setPower(speed);
        }

        public void moveBackwards(){
            FL.setPower(-speed);
            BL.setPower(-speed);
            FR.setPower(-speed);
            BR.setPower(-speed);
        }

        public void turnLeft(){
            FL.setPower(speed);
            BL.setPower(speed);
            FR.setPower(-speed);
            BR.setPower(-speed);
        }

        public void turnRight(){
            FL.setPower(-speed);
            BL.setPower(-speed);
            FR.setPower(speed);
            BR.setPower(speed);
        }

        public void stafeLeft(){
            FL.setPower(speed);
            BL.setPower(-speed);
            FR.setPower(-speed);
            BR.setPower(speed);
        }

        public void strafeRight(){
            FL.setPower(-speed);
            BL.setPower(speed);
           FR.setPower(speed);
            BR.setPower(-speed);
        }









    }




}
